<?php
    class Initialize{
        public function __construct(){
            $file = CTRL."/list_page.php";
            $cls  = "List_page";
            $mth  = false;

            $url = $this->urlCut();

            if(!empty($url[0])){
                $file = CTRL.DS.$url[0].".php";
                $cls  = ucfirst($url[0]);

                if(!empty($url[1])){
                    $mth = $url[1];
                }
            }else{
                $file = CTRL."/list_page.php";
                $cls  = "List_page";
                $mth  = false;
            }

            if(file_exists($file)){
                require_once $file;
                $ctrl = new $cls($mth);
            }else{
            //  ERROR 404
                echo "404<pre>Page not found!</pre>";
                return false;
            }
        }

/***********************************************
    METHODS
***********************************************/

        private function urlCut(){
            $url = explode("/",
                rtrim(
                    substr(
                        $_SERVER["REQUEST_URI"],
                    1),
                "/")
            );
            return $url;
        }
    }

    $initialize = new Initialize;
?>