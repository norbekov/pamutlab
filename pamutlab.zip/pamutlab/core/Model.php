<?php
    class Model extends DB{
        public function __construct(){
            
        }
    }
?>