<?php
    class View{
        public function __construct(){
            
        }

        public function render($view, $imain = false, $p_num = false, $onpage = false, $onstat = false){
            require_once VIEW.DS."ihead.php";
            require_once VIEW.DS.$view."/imain.php";
            require_once VIEW.DS."ifoot.php";
        }
    }
?>