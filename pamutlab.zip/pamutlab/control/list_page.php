<?php
    class List_page extends Control{
        public function __construct($m = false){
            parent::__construct();

            if($_SERVER["REQUEST_METHOD"] == "POST"){
                $msg = false;

                if(isset($_POST["edit"])){
                    $data = $_POST;

                    require_once "model".DS."edit_item.php";
                    $imain = new Editproject($data);

                    require_once "model".DS."project_list.php";
                    $imain = new Projectlist;
                    $p_num = $imain->numProject();
                    $imain = $imain->listProject();

                    $this->view->render("list_page", $imain, $p_num);
                }else if(isset($_POST["getpage"]) && !empty($_POST["getpage"])){
                    $sortby = "";
                    $onstat = "";
                    if(isset($_POST["getstat"]) && !empty($_POST["getstat"])){
                        $onstat = $_POST["getstat"];
                        $sortby = "WHERE statuses.name = '".$_POST["getstat"]."'";
                    }

                    $offset = $_POST["getpage"];
                    $onpage = $offset;

                    if($offset > 1){
                        $offset = ($offset * 10) - 10;
                    }else{
                        $offset = 0;
                    }

                    require_once "model".DS."project_list.php";
                    $imain = new Projectlist;
                    $p_num = $imain->numProject($sortby);
                    $imain = $imain->listProject($sortby, $offset);

                    $this->view->render("list_page", $imain, $p_num, $onpage, $onstat);
                }else if(isset($_POST["sortby"]) && !empty($_POST["sortby"])){
                    if(isset($_POST["onpage"]) && !empty($_POST["onpage"])){
                        $onstat = $_POST["sortby"];
                        $sortby = "WHERE statuses.name = '".$_POST["sortby"]."'";
                        $offset = $_POST["onpage"];
                        $onpage = $offset;

                        if($offset > 1){
                            $offset = ($offset * 10) - 10;
                        }else{
                            $offset = 0;
                        }

                        require_once "model".DS."project_list.php";
                        $imain = new Projectlist;
                        $p_num = $imain->numProject($sortby);
                        $imain = $imain->listProject($sortby, $offset);

                        $this->view->render("list_page", $imain, $p_num, $onpage, $onstat);
                    }
                }else{
                    $err = 0;
                    $msg = "Hiányzó adatok: \n";

                    if(isset($_POST["title"]) && !empty($_POST["title"])){
                        if(isset($_POST["stat"]) && !empty($_POST["stat"])){
                            if(isset($_POST["owner"]) && !empty($_POST["owner"])){
                                if(isset($_POST["email"]) && !empty($_POST["email"])){
                                    if(isset($_POST["desc"]) && !empty($_POST["desc"])){
                                        $data = array(
                                            "title" => $_POST["title"],
                                            "stat"  => $_POST["stat"],
                                            "owner" => $_POST["owner"],
                                            "email" => $_POST["email"],
                                            "desc"  => $_POST["desc"]
                                        );

                                        require_once "model".DS."delete_item.php";
                                        $imain = new Deleteitem;

                                        if($imain->deleteItem($data)){
                                            $msg = "Törölve :D";
                                        }else{
                                            $msg = "Nem sikerült :(";
                                        }
                                    }else{
                                        $err ++;
                                        $msg += "- Leírás \n";
                                    }
                                }else{
                                    $err ++;
                                    $msg += "- e-mail \n";
                                }
                            }else{
                                $err ++;
                                $msg += "- Kapcsolattartó \n";
                            }
                        }else{
                            $err ++;
                            $msg += "- Státusz \n";
                        }
                    }else{
                        $err ++;
                        $msg += "- Név \n";
                    }
                }

                if($msg){
                    echo "
                        <div id='msg_box' onClick='hideMsg(this);'>
                            <div id='msg'>
                                <div id='msg_title'>Értesítés</div> <hr />".$msg."
                            </div>
                        </div>
                    ";
                }
            }else{
                require_once "model".DS."project_list.php";
                $imain = new Projectlist;
                $p_num = $imain->numProject();
                $imain = $imain->listProject();

                $this->view->render("list_page", $imain, $p_num);
            }
        }
    }
?>