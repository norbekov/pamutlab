<?php
    class Create_page extends Control{
        public function __construct($m = false){
            parent::__construct();

            if($_SERVER["REQUEST_METHOD"] == "POST"){
                if(isset($_POST["data"]) && !empty($_POST["data"])){
                    $data = explode(",", $_POST["data"]);

                    require_once "model".DS."create_item.php";
                    $imain = new Createitem;

                    if($imain->createItem($data)){
                        echo "Sikeres feltöltés :D";
                    }else{
                        echo "Minden mező kitöltése kötelező!";
                    }
                }
            }else{
                $this->view->render("create_page");
            }
        }
    }
?>