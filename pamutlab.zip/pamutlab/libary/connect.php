<?php
    class DB{
        private $host      = "127.0.0.1",
                $dbname    = "welove_test",
                $charset   = "utf8mb4",
                $collation = "utf8mb4_unicode_ci",
                $username  = "root",
                $password  = "";

        protected function conn(){
            $pdo  = "mysql:host=".$this->host.
                    ";dbname="   .$this->dbname.
                    ";charset="  .$this->charset.
                    ";collation=".$this->collation;

            $conn = new PDO($pdo, $this->username, $this->password);
            $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            return $conn;
        }
    }

    $db = new DB;
?>