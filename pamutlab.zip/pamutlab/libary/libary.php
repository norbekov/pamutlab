<?php
    define("DS",   DIRECTORY_SEPARATOR, false);
    define("MODL", "model",             false);
    define("VIEW", "view",              false);
    define("CTRL", "control",           false);
?>