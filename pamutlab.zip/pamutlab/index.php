<?php
    session_start();

    error_reporting(NULL);
    mb_internal_encoding("UTF-8");

    require_once "libary".DIRECTORY_SEPARATOR."libary.php";
    require_once "libary".DS."connect.php";
    require_once "core".  DS."Model.php";
    require_once "core".  DS."View.php";
    require_once "core".  DS."Control.php";
    require_once "core".  DS."Initialize.php";
?>