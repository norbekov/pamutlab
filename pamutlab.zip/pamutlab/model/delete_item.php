<?php
    class Deleteitem extends Model{
        public function __construct(){
            
        }

        public function deleteItem($data){
            $sql = "SELECT `id` FROM `projects`
                    WHERE `title` = :title
                    AND `description` = :desc;
            ";

            $stmt = $this->conn()->prepare($sql);

            $stmt->bindParam(':title', $data["title"], PDO::PARAM_STR);
            $stmt->bindParam(':desc',  $data["desc"],  PDO::PARAM_STR);

            if($stmt->execute()){
                $p_id = $stmt->fetchAll();

                $sql = "
                    DELETE `project_owner_pivot`, `project_status_pivot`
                    FROM `projects`
                    INNER JOIN `project_owner_pivot` ON project_owner_pivot.project_id = projects.id
                    INNER JOIN `project_status_pivot` ON project_status_pivot.project_id = projects.id
                    WHERE projects.id = :p_id;
                    DELETE FROM `projects` WHERE `id` = :p_id;
                ";

                $stmt = $this->conn()->prepare($sql);
                $stmt->bindParam(':p_id', $p_id[0]["id"], PDO::PARAM_STR);

                if($stmt->execute()){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
    }
?>