<?php
    class Createitem extends Model{
        public function __construct(){
            
        }

        public function createItem($data){
            for($i = 0; $i < count($data); $i++){
                if(!isset($data[$i]) || empty($data[$i])){
                    return false;
                }
            }

            $sql = "
                BEGIN;
                    INSERT IGNORE INTO `owners` VALUES (DEFAULT, :name, :email);
                    INSERT INTO `projects` VALUES (DEFAULT, :title, :desc);
                    INSERT INTO `project_owner_pivot` (`project_id`, `owner_id`)
                    SELECT projects.id, owners.id FROM `projects`, `owners`
                    WHERE projects.title = :title AND owners.name = :name;
                    INSERT INTO `project_status_pivot` (`project_id`, `status_id`)
                    SELECT projects.id, statuses.id FROM `projects`, `statuses`
                    WHERE projects.title = :title AND statuses.name = :stat;
                COMMIT;
            ";

            $stmt = $this->conn()->prepare($sql);

            $stmt->bindParam(':title', $data[0], PDO::PARAM_STR);
            $stmt->bindParam(':desc',  $data[1], PDO::PARAM_STR);
            $stmt->bindParam(':stat',  $data[2], PDO::PARAM_STR);
            $stmt->bindParam(':name',  $data[3], PDO::PARAM_STR);
            $stmt->bindParam(':email', $data[4], PDO::PARAM_STR);

            if($stmt->execute()){
                return true;
            }else{
                return false;
            }
        }
    }
?>