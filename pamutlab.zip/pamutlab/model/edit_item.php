<?php
    class Editproject extends Model{
        public function __construct($data){
            $c_data = array();
            if($data["e_title"] != $data["o_title"]){
                array_push($c_data, $data["e_title"]);
            }
            if($data["e_desc"] != $data["o_desc"]){
                array_push($c_data, $data["e_desc"]);
            }
            if($data["e_stat"] != $data["o_stat"]){
                array_push($c_data, $data["e_stat"]);
            }
            if($data["e_email"] != $data["o_email"]){
                array_push($c_data, $data["e_email"]);
            }
            if($data["e_name"] != $data["o_name"]){
                array_push($c_data, $data["e_name"]);

                if(!$this->checkOwner($data["e_name"])){
                    if(!$this->updateOwner($data["e_name"], $data["e_email"])){
                        return false;
                    }
                }
            }

            if($this->updateProject($data)){
                $msg = "Új adatok a projekthez:\n";

                foreach($c_data as $c){
                    $msg .= "- ".$c."\n";
                }

                if(mail($data["o_email"], "Értesítés megváltozott adatokról", $msg)){
                    return true;
                }
            }else{
                return false;
            }
        }

        public function updateProject($data){
            $sql = "
                SET FOREIGN_KEY_CHECKS=0;
                UPDATE projects, project_owner_pivot, project_status_pivot
                SET projects.title = :title,
                    projects.description = :desc,
                    project_status_pivot.status_id = (SELECT id FROM statuses WHERE name = :stat),
                    project_owner_pivot.owner_id = (SELECT id FROM owners WHERE name = :name)
                WHERE projects.id = (SELECT id FROM projects WHERE title = '".$data["o_title"]."')
                AND project_owner_pivot.project_id = (SELECT id FROM projects WHERE title = '".$data["o_title"]."')
                AND project_status_pivot.project_id = (SELECT id FROM projects WHERE title = '".$data["o_title"]."');
                SET FOREIGN_KEY_CHECKS=1;
            ";

            $stmt = $this->conn()->prepare($sql);
            $stmt->bindParam(':title', $data["e_title"], PDO::PARAM_STR);
            $stmt->bindParam(':desc',  $data["e_desc"],  PDO::PARAM_STR);
            $stmt->bindParam(':stat',  $data["e_stat"],  PDO::PARAM_STR);
            $stmt->bindParam(':name',  $data["e_name"],  PDO::PARAM_STR);

            if($result = $stmt->execute()){
                 return true;
            }else{
                print_r($stmt->errorInfo());
            }
        }

        public function updateOwner($name, $email){
            $sql = "INSERT INTO owners (name, email) VALUES (:name, :email);";

            $stmt = $this->conn()->prepare($sql);

            $stmt->bindParam(':name',  $name,  PDO::PARAM_STR);
            $stmt->bindParam(':email', $email, PDO::PARAM_STR);

            if($stmt->execute()){
                return true;
            }else{
                return false;
            }
        }

        public function checkOwner($owner){
            $sql = "SELECT * FROM owners WHERE owners.name = :owner";

            $stmt = $this->conn()->prepare($sql);
            $stmt->bindParam(':owner', $owner, PDO::PARAM_STR);

            if($stmt->execute()){
                if($stmt->fetchColumn() > 0){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
    }
?>