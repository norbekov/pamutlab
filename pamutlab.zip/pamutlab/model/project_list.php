<?php
    class Projectlist extends Model{
        public function __construct(){
            
        }

        public function numProject($sortby = false){
            if($sortby == false){
                $sortby = "";
            }

            $sql = "
                SELECT projects.id,
                       statuses.name
                FROM projects
                INNER JOIN project_status_pivot ON projects.id = project_status_pivot.project_id
                INNER JOIN statuses ON statuses.id = project_status_pivot.status_id
                ".$sortby."
                ORDER BY projects.id ASC;
            ";

            $stmt = $this->conn()->prepare($sql);

            if($stmt->execute()){
                $result = $stmt->rowCount();
                return $result;
            }else{
                return false;
            }
        }

        public function listProject($sortby = false, $offset = false){
            if($sortby == false){
                $sortby = "";
            }

            if($offset == false){
                $offset = 0;
            }

            $sql = "
                SELECT projects.title,
                       projects.description,
                       owners.name,
                       owners.email,
                       statuses.key AS stat_key,
                       statuses.name AS stat
                FROM projects
                INNER JOIN project_owner_pivot ON projects.id = project_owner_pivot.project_id
                INNER JOIN project_status_pivot ON projects.id = project_status_pivot.project_id
                INNER JOIN owners ON owners.id = project_owner_pivot.owner_id
                INNER JOIN statuses ON statuses.id = project_status_pivot.status_id
                ".$sortby."
                ORDER BY projects.id DESC
                LIMIT 10 OFFSET ".$offset.";
            ";

            $stmt = $this->conn()->prepare($sql);

            if($stmt->execute()){
                $result = $stmt->fetchAll();
                return $result;
            }else{
                return false;
            }
        }
    }
?>