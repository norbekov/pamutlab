/***********************************************
    NOTIFICATION
***********************************************/

function hideMsg(e){
    e.remove();
}

/***********************************************
    PROJECTS PAGE
***********************************************/

//  ACTUAL PAGE

window.onload = function(){
    if(page = document.getElementById("page")){
        var onp   = document.getElementById("on_p").value;
        var pages = document.getElementById("page").childNodes;

        for(var i = 0; i < pages.length; i++){
            if(pages[i].innerHTML == onp){
                pages[i].style.color = "#ff0000";
            }
        }
    }
};

// CHANGE PAGE

function getPage(e){
    var data = e.innerHTML;
    var stat = "";

    var form = document.createElement("form");
    form.setAttribute("id", "getpage_form");
    form.setAttribute("action", "");
    form.setAttribute("method", "POST");
    document.body.appendChild(form);

    var ipt = document.createElement("input");
    ipt.setAttribute("type", "hidden");
    ipt.setAttribute("name", "getpage");
    form.appendChild(ipt);

    ipt.value = data;

    if(stat = document.getElementById("on_s")){
        form.appendChild(stat);
    }

    form.submit();
}

//  SORT BY STATUS

function sortBy(e){
    var data = e.innerHTML;
    var onp  = 1;

    var form = document.createElement("form");
    form.setAttribute("id", "sortby_form");
    form.setAttribute("action", "");
    form.setAttribute("method", "POST");
    document.body.appendChild(form);

    var ipt = document.createElement("input");
    ipt.setAttribute("type", "hidden");
    ipt.setAttribute("name", "sortby");
    form.appendChild(ipt);
    ipt.value = data;

    var onpage = document.createElement("input");
    onpage.setAttribute("type", "hidden");
    onpage.setAttribute("name", "onpage");
    form.appendChild(onpage);
    onpage.value = onp;

    form.submit();
}

//  DELETE ITEM

function delItem(e){
    var card  = e.parentNode.parentNode;
    var items = card.childNodes;

    for(var i = 0; i < items.length; i++){
        var title = items[0].outerText;
        var stat  = items[1].outerText;
        var owner = items[2].childNodes[0].outerText;
        var email = items[2].childNodes[1].outerText;
            email = email.substring(1, email.length - 1);
        var desc  = items[3].outerText;
    }

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
        if(xhttp.readyState === 4 && xhttp.status === 200){
            var r = xhttp.responseText;
            document.getElementById("r_text").innerHTML = r;
        }
    };

    xhttp.open("POST", "", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send(
        "title="  + title +
        "&stat="  + stat  +
        "&owner=" + owner +
        "&email=" + email +
        "&desc="  + desc
    );

//  SLIDE ANIMATION

    var card = e.parentNode.parentNode;
    var pos  = 25;
    var opa  = 1;

    var anim = setInterval(function(){
        if(pos == -50){
            card.style.display = "none";
            clearInterval(this);
        }else{
            pos--;
            opa -= 0.02;
            card.style.marginLeft = pos + "%";
            card.style.opacity    = opa;
        }
    }, 20);
}

//  EDIT ITEM

function editItem(e){
    var item  = e.parentNode.parentNode;
    var ipts  = item.childNodes;
    var owner = ipts[2].childNodes;

    var title = ipts[0].innerHTML;
    var stat  = ipts[1].innerHTML;
    var name  = owner[0].innerHTML;
    var email = owner[1].innerHTML;
        email = email.substring(1, email.length - 1);
    var desc  = ipts[3].innerHTML;

    var e_bg = document.createElement("div");
    e_bg.setAttribute("id", "e_bg");
    document.body.appendChild(e_bg);

    var e_box = document.createElement("div");
    e_box.setAttribute("id", "e_box");
    e_bg.appendChild(e_box);

    var e_head = document.createElement("h3");
    e_head.setAttribute("id", "e_head");
    e_box.appendChild(e_head);
    e_head.innerHTML = "Projekt szerkesztése";

    var hr = document.createElement("hr");
    e_box.appendChild(hr);

    var form = document.createElement("form");
    form.setAttribute("id", "e_form");
    form.setAttribute("action", "");
    form.setAttribute("method", "POST");
    e_box.appendChild(form);

    var edit_txt = document.createElement("input");
    edit_txt.setAttribute("type", "hidden");
    edit_txt.setAttribute("name", "edit");
    form.appendChild(edit_txt);

    //  TITLE

    var title_label = document.createElement("p");
    form.appendChild(title_label);
    title_label.innerHTML = "Cím";

    var e_title = document.createElement("input");
    e_title.setAttribute("id", "e_title");
    e_title.setAttribute("name", "e_title");
    e_title.setAttribute("class", "ipt");
    e_title.setAttribute("type", "text");
    form.appendChild(e_title);
    e_title.value = title;

        var o_title = document.createElement("input");
        o_title.setAttribute("name", "o_title");
        o_title.setAttribute("type", "hidden");
        form.appendChild(o_title);
        o_title.value = title;

    //  STATUS

    var stat_label = document.createElement("p");
    form.appendChild(stat_label);
    stat_label.innerHTML = "Státusz";

    var e_stat = document.createElement("div");
    e_stat.setAttribute("id", "e_stat");
    e_stat.setAttribute("onmouseover", "selectStat(this);");
    e_stat.setAttribute("onmouseout", "closeStat(this);");
    form.appendChild(e_stat);

        var stat_wrapper = document.createElement("div");
        stat_wrapper.setAttribute("id", "stat_wrapper");
        e_stat.appendChild(stat_wrapper);
        stat_wrapper.innerHTML = stat;

        var stat_box = document.createElement("div");
        stat_box.setAttribute("id", "stat_box");
        e_stat.appendChild(stat_box);

            var stat_todo = document.createElement("div");
            stat_todo.setAttribute("class", "stat_item");
            stat_todo.setAttribute("onClick", "setStat(this);");
            stat_box.appendChild(stat_todo);
            stat_todo.innerHTML = "Fejlesztésre vár";

            var stat_in_progress = document.createElement("div");
            stat_in_progress.setAttribute("class", "stat_item");
            stat_in_progress.setAttribute("onClick", "setStat(this);");
            stat_box.appendChild(stat_in_progress);
            stat_in_progress.innerHTML = "Folyamatban";

            var stat_done = document.createElement("div");
            stat_done.setAttribute("class", "stat_item");
            stat_done.setAttribute("onClick", "setStat(this);");
            stat_box.appendChild(stat_done);
            stat_done.innerHTML = "Kész";

    var stat_ipt = document.createElement("input");
    stat_ipt.setAttribute("type", "hidden");
    stat_ipt.setAttribute("id", "stat");
    stat_ipt.setAttribute("name", "e_stat");
    form.appendChild(stat_ipt);
    stat_ipt.value = stat;

        var o_stat = document.createElement("input");
        o_stat.setAttribute("name", "o_stat");
        o_stat.setAttribute("type", "hidden");
        form.appendChild(o_stat);
        o_stat.value = stat;

    //  NAME

    var name_label = document.createElement("p");
    form.appendChild(name_label);
    name_label.innerHTML = "Név";

    var e_name = document.createElement("input");
    e_name.setAttribute("id", "e_name");
    e_name.setAttribute("name", "e_name");
    e_name.setAttribute("class", "ipt");
    e_name.setAttribute("type", "text");
    form.appendChild(e_name);
    e_name.value = name;

        var o_name = document.createElement("input");
        o_name.setAttribute("name", "o_name");
        o_name.setAttribute("type", "hidden");
        form.appendChild(o_name);
        o_name.value = name;

    //  E-MAIL

    var email_label = document.createElement("p");
    form.appendChild(email_label);
    email_label.innerHTML = "e-mail";

    var e_email = document.createElement("input");
    e_email.setAttribute("id", "e_email");
    e_email.setAttribute("name", "e_email");
    e_email.setAttribute("class", "ipt");
    e_email.setAttribute("type", "text");
    form.appendChild(e_email);
    e_email.value = email;

        var o_email = document.createElement("input");
        o_email.setAttribute("name", "o_email");
        o_email.setAttribute("type", "hidden");
        form.appendChild(o_email);
        o_email.value = email;

    //  DESCRIPTION

    var desc_label = document.createElement("p");
    form.appendChild(desc_label);
    desc_label.innerHTML = "Leírás";

    var e_desc = document.createElement("input");
    e_desc.setAttribute("id", "e_desc");
    e_desc.setAttribute("name", "e_desc");
    e_desc.setAttribute("class", "ipt");
    e_desc.setAttribute("type", "text");
    form.appendChild(e_desc);
    e_desc.value = desc;

        var o_desc = document.createElement("input");
        o_desc.setAttribute("name", "o_desc");
        o_desc.setAttribute("type", "hidden");
        form.appendChild(o_desc);
        o_desc.value = desc;

    //  BUTTONS

    var e_save = document.createElement("div");
    e_save.setAttribute("id", "e_save");
    e_save.setAttribute("onClick", "editSave(this);");
    form.appendChild(e_save);
    e_save.innerHTML = "Mentés";

    var e_close = document.createElement("div");
    e_close.setAttribute("id", "e_close");
    e_close.setAttribute("onClick", "editClose(this);");
    form.appendChild(e_close);
    e_close.innerHTML = "Mégse";
}

//  EDIT CLOSE

function editClose(e){
    e.parentNode.parentNode.parentNode.remove();
}

//  EDIT SAVE

function editSave(e){
    var form = e.parentNode;
    var ipts = form.querySelectorAll(".ipt");

    for(var i = 0; i < ipts.length; i++){
        if(ipts[i].value == null || ipts[i].value == ""){
            var e_text = document.createElement("div");
            e_text.setAttribute("id", "e_text");
            e_box.appendChild(e_text);
            document.getElementById("e_text").innerHTML = "Minden adat megadása kötelező!";
            return false;
        }
    }

    form.submit();
}

//  CHANGE STATUS

function selectStat(e){
    var stat = e.childNodes[1];
    stat.style.display = "block";
}

function closeStat(e){
    var stat = e.childNodes[1];
    stat.style.display = "none";
}

function setStat(e){
    var txt  = e.innerHTML;
    var box  = e.parentNode;
    var stat = e.parentNode.parentNode.childNodes[0];
    var data = document.getElementById("stat");

    data.value = txt;
    stat.innerHTML = txt;
    box.style.display = "none";
}

//  DESCRIPTION

function showDescription(e){
    var card = e.parentNode.childNodes;
    console.log(card[3].innerHTML);

    var box = document.createElement("div");
    box.setAttribute("id", "msg_box");
    box.setAttribute("onclick", "hideDescription(this);");
    document.body.appendChild(box);

    var wrap = document.createElement("div");
    wrap.setAttribute("id", "msg");
    document.getElementById("msg_box").appendChild(wrap);

    var tit = document.createElement("div");
    tit.setAttribute("id", "msg_title");
    document.getElementById("msg").appendChild(tit);

    tit.innerHTML  = "A projekt leírása";

    var hr = document.createElement("hr");
    document.getElementById("msg").appendChild(hr);

    var desc = document.createElement("div");
    desc.setAttribute("id", "msg_title");
    document.getElementById("msg").appendChild(desc);

    desc.innerHTML = card[3].innerHTML;
}

function hideDescription(e){
    e.remove();
}

/***********************************************
    CREATE PAGE
***********************************************/

//  ADD NEW ITEM

function addNewItem(){
	var title = document.getElementById("title").value;
	var desc  = document.getElementById("desc").value;
	var stat  = document.getElementById("stat").value;
	var owner = document.getElementById("name").value;
	var email = document.getElementById("email").value;

    var data = [title, desc, stat, owner, email];

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
        if(xhttp.readyState === 4 && xhttp.status === 200){
            var r = xhttp.responseText;
            if(r == "Sikeres feltöltés :D"){
                document.getElementById("r_text").style.color = "#00ff00";
            }else{
                document.getElementById("r_text").style.color = "#ff0000";
            }
            document.getElementById("r_text").innerHTML = r;
        }
    };

    xhttp.open("POST", "", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("data=" + data);
}

//  CHANGE STATUS

function statSelect(e){
    var stat = e.childNodes[3];
    stat.style.display = "block";
}

function statClose(e){
    var stat = e.childNodes[3];
    stat.style.display = "none";
}

function changeStat(e){
    var txt  = e.innerHTML;
    var box  = e.parentNode;
    var stat = e.parentNode.parentNode.childNodes[1];
    var data = document.getElementById("stat");

    box.style.display = "none";
    data.value = txt;
    stat.innerHTML = txt;
}