<main>
    <?php
        if($imain){
            foreach($imain as $t){
                echo "<div class='p_card'>";
                    echo "<div class='p_title' onClick='showDescription(this);' title='Projekt tartalma'>".$t['title']."</div>";

                    echo "<div class='p_stat' title='Szűrés: ".$t['stat']."' onClick='sortBy(this);'>". $t['stat']."</div>";
                    echo "<div class='p_contact'>";
                        echo "<div class='p_owner'>".$t['name']."</div>";
                        echo "<div class='p_email'>(".$t['email'].")</div>";
                    echo "</div>";
                    echo "<div class='p_desc'>". $t['description']."</div>";

                    echo "<div class='p_button_box'>";
                        echo "<div class='p_edit p_button' onClick='editItem(this);'>Szerkesztés</div>";
                        echo "<div class='p_del  p_button' onClick=delItem(this);>Törlés</div>";
                    echo "</div>";
                echo "</div>";
            }

            if($p_num){
                $p_num = ceil($p_num / 10);

                if(!$onpage){
                    $onpage = 1;
                }

                if($p_num <= 5){
                    echo "<div id='page'>";
                        for($i = 1; $i <= $p_num; $i++){
                            echo "<div class='pages' title='".$i.". oldal' onClick='getPage(this);'>".$i."</div>";
                        }
                    echo "</div>";
                }else{
                    echo "<div id='page'>";
                        echo "<div class='pages' title='Első oldal' onClick='getPage(this);'>1</div>";

                        if($onpage > 2){
                            echo "<div class='pages' title='".($onpage - 1).". oldal' onClick='getPage(this);'>".($onpage - 1)."</div>";
                        }

                        if($onpage > 1 && $onpage < $p_num){
                            echo "<div id='onpage' class='pages' title='".$onpage.". oldal' onClick='getPage(this);'>".$onpage."</div>";
                        }

                        if($onpage < $p_num - 1){
                            echo "<div class='pages' title='".($onpage + 1).". oldal' onClick='getPage(this);'>".($onpage + 1)."</div>";
                        }

                        echo "<div class='pages' title='Utolsó oldal' onClick='getPage(this);'>".$p_num."</div>";
                    echo "</div>";
                }

                echo "<input type='hidden' name='on_p' id='on_p' value='".$onpage."' />";

                if($onstat){
                    echo "<input type='hidden' name='getstat' id='on_s' value='".$onstat."' />";
                }
            }
        }else{
            echo "<h3>Elfogyott xD</h3>";
        }
    ?>
    <div id="r_text"></div>
</main>