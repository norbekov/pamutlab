<main>
    <div id="create_item_box">
        <form id="create_form" action='' method="POST">
            <p>Cím</p>
            <input type='text' id='title' class='ipt' name='title' placeholder='Title'       />
            <p>Leírás</p>
            <input type='text' id='desc'  class='ipt' name='desc'  placeholder='Description' />
            <p>Státusz</p>
            <input type='hidden' id='stat'  class='ipt' name='stat' value="Fejlesztésre vár" />
            <div id="stat_container">
                <div id="stat_ipt" onmouseover="statSelect(this);" onmouseout="statClose(this);">
                    <div id="stat_wrapper">Fejlesztésre vár</div>
                    <div id="stat_box">
                        <div class="stat_item" onClick="changeStat(this);">Fejlesztésre vár</div>
                        <div class="stat_item" onClick="changeStat(this);">Folyamatban</div>
                        <div class="stat_item" onClick="changeStat(this);">Kész</div>
                    </div>
                </div>
            </div>
            <p>Kapcsolattartó</p>
            <input type='text' id='name'  class='ipt' name='name'  placeholder='Contact'     />
            <p>e-mail</p>
            <input type='text' id='email' class='ipt' name='email' placeholder='e-mail'      />
            <div id="save_button" onClick="addNewItem();">Mentés</div>
        </form>

        <div id="r_text"></div>
    </div>
</main>