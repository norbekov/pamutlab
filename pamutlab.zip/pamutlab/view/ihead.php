<!DOCTYPE html>
<html>
<head>
    <meta charset  = "UTF-8" />
    <meta name     = "viewport"      content = "width=device-width, initial-scale=1" />
    <meta name     = "author"        content = "Kovács Norbert" />
    <meta name     = "copyright"     content = "www.pamutlabor.hu" />
    <meta property = "og:url"        content = "https://www.pamutlabor.hu" />
    <meta name     = "keywords"      content = "PamutLabor, Egyedi, Póló, Ajándék" />
    <meta name     = "description"   content = "Egyedi pólók csak Neked! Bármilyen ajándékot keresel, nálunk tuti megtalálod." />
    <link rel      = "stylesheet"    type    = "text/css" href="../style/default.css" />
    <link rel="shortcut icon"        href="image/logo.jpg" />
    <title>PamutLabor</title>

    <script type="text/JavaScript" src="../script/pamut.js"></script>
</head>
<body>
    <noscript>Enable JavaScript in your browser!</noscript>
    <header>
        <a href="https://www.pamutlabor.hu" target="_blank"><div id="h_logo">WeLove Test</div></a>
        <a href="list_page"                 target="_self"><div  class="h_item" id="h_list">Projektlista</div></a>
        <a href="create_page"               target="_self"><div  class="h_item" id="h_create">Létrehozás</div></a>
    </header>